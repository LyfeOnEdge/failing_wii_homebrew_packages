============
 BRAWLSTATS
============

BrawlStats es una aplicaci�n para Wii que tendr� que ser ejecutada
despu�s de una larga sesi�n de Super Smash Bros. Brawl Brawl.
Guardar� autom�ticamente tus resultados en la SD y luego podr�s navegar
por una atractiva interfaz gr�fica que te permitir� ver los resultados de
ese d�a: cu�ntas horas se han jugado, cu�ntas batallas se han librado,
qui�n ha hecho m�s victorias, etc. Dar� trofeos a los jugadores que
superen ciertos r�cords y adem�s mostrar� informaci�n que SSBB guarda
pero no muestra en pantalla.
Ser� como una base de datos de vuestras partidas de Smash Bros. Brawl.


�Qu� necesito?
--------------
* Homebrew Channel 1.0.7 o superior
* Datos de partida Super Smash Bros. Brawl (PAL o NTSC-USA)
* Tarjeta SD


Uso
---
Ejecutad BrawlStats por primera vez. Esto crear� los datos necesarios en la SD.

Una vez teng�is los datos creados, ya pod�is jugar al Brawl todo lo que quer�is.

Despu�s de la sesi�n de Brawl, ten�is que ejecutar BrawlStats otra vez. Os
preguntar� si quer�is crear una nueva sesi�n, ten�is que seleccionar siempre S�.
�Y ya podr�is ver toda la informaci�n de esa sesi�n! :D

De ahora en adelante, tendr�is que ejecutar BrawlStats despu�s de cada sesi�n de
Brawl.
Si no segu�s esta norma, la pr�xima sesi�n que cre�is tendr� la informaci�n de la
�ltima sesi�n sumada a la de la anterior que no se guard�, as� que acordaos de
ejecutar BrawlStats despu�s de cualquier sesi�n.


Men� y controles
----------------
BrawlStats tiene una simple interfaz gr�fica que dividiremos por pesta�as, y cada
pesta�a estar� dividida en diferentes p�ginas.

Controles:
* A: p�gina siguiente
* B: p�gina anterior
* +: pesta�a siguiente
* -: pesta�a anterior
* D-PAD: navegar y/o desplazarse por las tablas de la p�gina actual
* 2: guardar captura de pantalla en la SD
* HOME: pantalla de ayuda/salir

Explicaci�n de pesta�as y p�ginas:

* PESTA�A 1: Sesiones
  La m�s importante. Primero estar� vac�a, pero despu�s de cada sesi�n ir�
  guardando m�s y m�s informaci�n, convirti�ndose en una base de datos de Brawl.
   * P�g. 1: Lista de sesiones, tambi�n muestra los ganadores de la sesi�n seleccionada.
             Arriba/abajo: seleccionar sesi�n.
   * P�g. 2: Clasificaci�n de jugadores de la sesi�n seleccionada.
             Izq./Der.: cambiar el orden de la tabla.
             Arriba/abajo: desplazarse por la tabla.
   * P�g. 3: Clasificaci�n de personajes de la sesi�n seleccionada.
             Izq./Der.: cambiar el orden de la tabla.
             Arriba/abajo: desplazarse por la tabla.
   * P�g. 4: Estad�sticas tipo-Melee.
             Solo estar� disponible si los jugadores no han usado los mismos
             personajes en la sesi�n seleccionada.

* PESTA�A 2: Jugadores
  Aqu� puedes ver las estad�sticas generales de los jugadores.
   * P�g. 1: Lista de jugadores
             Izq./Der.: hojear jugadores.
             Arriba/abajo: desplazarse por la tabla de tiempo de uso de personajes.
   * P�g. 2: Clasificaci�n general de jugadores.
             Izq./Der.: cambiar el orden de la tabla.
             Arriba/abajo: desplazarse por la tabla.
   * P�g. 3: Clasificaci�n general de jugadores (por combate).
             Izq./Der.: cambiar el orden de la tabla.
             Arriba/abajo: desplazarse por la tabla.

* PESTA�A 3: Personajes
  Aqu� puedes ver las estad�sticas generales de los personajes.
   * P�g. 1: Lista de personajes.
             Izq./Der.: hojear personajes.
             Arriba/abajo: desplazarse por la tabla de KO.
   * P�g. 2: Clasificaci�n general de personajes.
             Izq./Der.: cambiar el orden de la tabla.
             Arriba/abajo: desplazarse por la tabla.
   * P�g. 3: Clasificaci�n general de personajes (por combate).
             Izq./Der.: cambiar el orden de la tabla.
             Arriba/abajo: desplazarse por la tabla.

* PESTA�A 4: General y ayuda
   * Muestra estad�sticas generales como total de combates o tiempo de juego
     y una peque�a ayuda para navegar en BrawlStats.
     HOME: Salir.


Recargar IOS
------------
BrawlStats v1 usa AHBPROT para tener acceso a la NAND y leer la partida de SSBB.
Pero si lo prefieres, tambi�n puedes forzar la recarga de un IOS.
Elimina las lineas de comentario (<!-- y -->) y modifica el n�mero del IOS a
utilizar en el archivo meta.xml. Ejemplo para IOS236:
<arguments>
    <arg>--ios=236</arg>
</arguments>


Historial
---------
beta1 (2010.02.09)
* primera versi�n

beta2 (2010.02.27)
* algunos bugs menores corregidos
* algunos cambios est�ticos
* a�adido indicador de p�gina para saber en qu� p�gina est�s
* la clasificaci�n por combates ahora muestra una nueva columna con el total de combates
* a�adida pantalla de ayuda en la �ltima pesta�a
* la funci�n de volver al men� de Wii funciona
* las cifras ahora usan una fuente de anchura fija

beta3 (2010.03.15)
* corregido un bug muy importante al llegar a la sesi�n 10

RC1 (2010.08.31)
* interfaz gr�fica totalmente renovada
* a�adido el sistema de trofeos

v1 (2010.12.13)
* usa AHBPROT, ya no se necesita ning�n cIOS (meta.xml tambi�n se actualiz�)
* las sesiones se guardan ahora en sd:/config/brawlstats/, deber�s mover tus
  antiguas sesiones a la nueva ruta

v1.1 (2011.03.09)
* arreglado AHBPROT para IOS antiguos, ahora es m�s compatible
* arreglado Porcentaje de uso BrawlStats en la �ltima pesta�a
* a�adida opci�n de captura de pantalla (pulsa 2 en cualquier p�gina)
* navegaci�n por tablas m�s r�pida manteniendo arriba/abajo
* algunos cambios est�ticos

v1.2 (2011.04.30)
* avisa al usuario si la sesi�n no se cre� correctamente
  (debido a una tarjeta SD corrupta, por ejemplo)
* muestra una barra de carga cuando lee las sesiones de la SD




--by Marc
http://usuaris.tinet.cat/mark/