Hi!

Use ComixChannel Resizer to prepare zip archive, then put Zip archives in SD:/comics/.