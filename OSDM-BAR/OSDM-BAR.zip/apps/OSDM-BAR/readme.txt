Product name    : OSDM-BAR Dentro
Coder           : NoNameNo from GRRLIB Team
Date            : 30/11/2009 

Informations:
I'm very happy to provide you this tiny demo to promote the very soon comming version of GRRLIB.
Like you will see, lot of great new stuff in the next GRRLIB Release...
In the same time it promote also the soon comming first WII Mega Demo Called "WII BOMB".
If you want to contribute to this demo, know that you can send your (screen/intro/production/etc...)
there is still available space for people wanted to join de demo.

GReetings :
Crayon, BlueChip, Xane, chris_c aka DaShAmAn, RedShade, all GRRLIB Contributors

Contact/Forum
Http://grrlib.santo.fr

See ya....
